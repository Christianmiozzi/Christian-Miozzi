import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';
import { User } from '../auth.service';
import { Client, ClientService } from '../client.service';
import { subscribeOn } from 'rxjs';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  username: string = '';
  password: string = '';

  form: FormGroup;
  loginForm: any;


  constructor(private clientService: ClientService, private router: Router, private authService: AuthService, private fb: FormBuilder) {
    this.form = this.fb.group({
      username: ['', Validators.required],
      password: ['', [Validators.required, Validators.minLength(2)]]
    });

  }



  onSubmit(): void {
    // this.authService.getUsers().subscribe({
    //   next: (users: User[]) =>{
    //     console.log('Users:', users);
    //   },
    //   error:(err) =>{
    //     console.error('errore del server',err);
    //   },
    //   complete: () =>{
    //     console.log('completata');
    if (this.form.valid) {
      const username = this.form.get('username')?.value;
      const password = this.form.get('password')?.value;


      this.authService.authenticate(username, password).subscribe({
        next: (user) => {

          if (user) {
            sessionStorage.setItem('userId', user.id.toString());
            this.router.navigate(['/list']);
          } else {
            alert('errata');
          }
        },
        error: (err) => {
          console.error('errore del server', err);
        }

      });
    }
  }
}


//  onSubmit(): void{
//   console.log(this.form.value);
//   this.router.navigate(['/list'])
//  }



