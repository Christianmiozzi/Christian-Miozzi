import { Component, OnInit } from '@angular/core';
import { Client, ClientService } from '../client.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';



@Component({
  selector: 'app-lista',
  templateUrl: './lista.component.html',
  styleUrl: './lista.component.css'
})
export class ListaComponent implements OnInit {
  customers: Client[] = [];

  displayedColumns: string[] = ['nome', 'cognome', 'email', 'azienda', 'codicefiscale', 'datadinascita', 'edit', 'delete'];

  isvisible: boolean = false;

  selectedClient: number | null = null;
  isVisibleEdit: boolean = false;

  userForm: FormGroup;


  selectedClientId: number | null = null;
  constructor(private clientService: ClientService, private fb: FormBuilder) {
    this.userForm = this.fb.group({
      codiceFiscale: ['', Validators.required],
      nome: ['', Validators.required],
      cognome: ['', Validators.required],
      dataDiNascita: ['', Validators.required]

    });

  }

  ngOnInit(): void {
    this.getClient();
  }

  mostra(): void {
    this.isvisible = !this.isvisible;
  }

  getClient(): void {
    let id = sessionStorage.getItem('userId');
    this.clientService.getClientsById(parseInt(id as string)).subscribe({
      next: (clients) => {
        this.customers = clients;

      },
      error: (error) => {
        console.error('errore recupero clienti', error);
      }
    });
  }

  onEdit(customer: Client): void {
    this.isvisible = true;
    this.userForm.patchValue({
      codiceFiscale: customer.codicefiscale,
      nome: customer.nome,
      cognome: customer.cognome,
      dataDiNascita: customer.datadinascita
    });

    this.selectedClientId = customer.id !== undefined ? customer.id : null;
  }


  onSubmit(): void {
    if (this.userForm.valid) {
      if (this.selectedClientId === null) {
        let id = sessionStorage.getItem('userId');
        const cliente: Client = { ...this.userForm.value, userId: id };
        this.clientService.addClient(cliente).subscribe({
          next: (response) => {
            this.getClient();
          },
          error: (error) => {
            console.error('Errore aggiunta cliente', error);
          }
        });
      } else {
        let UserId = sessionStorage.getItem('userId');
        const cliente = { ...this.userForm.value, userId: UserId, id: this.selectedClientId };
        this.clientService.updateClient(cliente).subscribe({
          next: (response) => {
            this.getClient();
          },
          error: (error) => {
            console.error('Errore aggiornamento cliente', error);
          }
        });

      }
    }
  }
  onDelete(clientid: number): void {
    if (confirm('Sei sicuro di voler eliminare questo cliente?')) {
      this.clientService.onDeleteClient(clientid).subscribe({
        next: () => {
          console.log('Client ID per l\'eliminazione:', clientid);

          this.getClient();
        },
        error: (error) => {
          console.error("Errore durante l'eliminazione del cliente con ID ${clientId}:, error");
        }
      });
    }
  }
}



